<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php arrays</title>
</head>

<body>
    PHP Arrays
    <hr />

    <?php
    // create array
    $array1 = array("red", "blue", "yellow");
    //echo $array1[0];
    //var_dump($array1);
    //print_r($array1);

    $array2 = ["aaa", "bbb", "ccc"];
    //echo $array2;
    //var_dump($array2);

    //add items to array
    //add to end
    array_push($array1, "black", "gray", "violet");
    print_r($array1);

    echo "<br />";

    //add using []
    $array1[] = "white";
    print_r($array1);

    echo "<br />";

    //add item in first position
    array_unshift($array1, "teal");
    print_r($array1);

    echo "<br />";

    //add item in specified position
    array_splice($array1, 2, 0, "third");
    print_r($array1);

    echo "<br />";

    //replace item in position
    $array1[3] = "fourth";
    print_r($array1);

    echo "<br />";

    //remove last item
    array_pop($array1);
    print_r($array1);

    echo "<br />";

    //remove by index
    unset($array1[1]);
    print_r($array1);

    echo "<br />";

    //remove by value
    //result of array_diff should be captured
    $array1 = array_diff($array1, ["violet"]);
    print_r($array1);

    echo "<br />";

    ?>





</body>

</html>