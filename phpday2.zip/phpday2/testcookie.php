<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>test cookie</title>
</head>

<body>
    do i have a cookie?<br />

    <?php
    if (isset($_COOKIE['cookie1'])) {
        echo $_COOKIE['cookie1'];
    } else {
        echo "you do not have any cookie";
    }
    ?>



</body>

</html>