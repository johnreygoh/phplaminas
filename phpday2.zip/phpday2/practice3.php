<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie Demo</title>
</head>

<body>

    you have created a cookie by visiting here <br />

    <?php
    setcookie("cookie1", "choco cookies", time() + 20)
    ?>

    <?php
    //to clear cookies
    // setcookie("cookie1","",time()+0)
    // unset($_COOKIE['cookie1'])
    ?>




</body>

</html>