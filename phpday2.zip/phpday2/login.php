<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Sessions</title>
</head>

<body>
    login
    <hr />

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        username <input type="text" name="username" required><br />
        password <input type="password" name="password" required><br />
        <input type="submit" name="submit1">
    </form>

    <?php
    if (isset($_POST['submit1'])) {
        $u = $_POST['username'];
        $p = $_POST['password'];
        if ($u == 'admin' && $p == '123') {
            $_SESSION['success'] = 'yes';
            echo "Welcome <b><i>$u</b></i>!";
        } else {
            unset($_SESSION['success']);
            echo "Incorrect credentials";
        }
    }
    ?>


</body>

</html>