<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add record</title>
</head>

<body>

    Add record
    <hr />

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        name <input type="text" name="name" required><br />
        department <input type="text" name="department" required><br />
        salary <input type="number" name="salary" required><br />
        <input type="submit" name="submit1">
    </form>


    <?php
    if (isset($_POST['submit1'])) {
        $n = $_POST['name'];
        $d = $_POST['department'];
        $s = $_POST['salary'];

        require("dbconnection/connect.php");
        $query = "insert into employees 
                (name,department,salary)
                values ('$n','$d',$s)";

        // run query
        mysqli_query($con, $query) or die(mysqli_error($con));
        echo "User <b>$user</b> added successfully";
        mysqli_close($con);

        //redirect to view records
        header("LOCATION:viewrecords.php");
    }
    ?>

</body>

</html>