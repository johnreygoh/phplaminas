<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php day 2</title>
</head>

<body>

    php day 2<br />
    <a href="practice1.php">practice1</a><br />
    <a href="practice2.php">practice2</a><br />
    <a href="practice3.php">practice3</a><br />
    <a href="testcookie.php">test cookie</a><br />
    <a href="viewrecords.php">view records</a><br />





</body>

</html>