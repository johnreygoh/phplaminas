<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practice2</title>
</head>

<body>

    classes,methods,objects
    <hr />

    <?php
    require("classes/Employee.php");
    //outside class
    $emp = new Employee();
    $emp->name = "jose";
    $emp->address = "Pasig";
    echo $emp->getemployee();
    ?>

    <hr />

    <?php
    require("classes/Product.php");
    $prod = new Product("bbb", 555, 20);
    echo $prod->getproduct();
    echo $prod->name;
    ?>

    <hr />

    <?php
    require("classes/Manilaproduct.php");
    $mp = new Manilaproduct("sss", 450, 12);
    echo $mp->getproduct();

    ?>





</body>

</html>