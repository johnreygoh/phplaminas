<?php

$host = "localhost";
$user = "adminjohn"; //user input
$pass = "123";
$db = "laminasdb";

$con = mysqli_connect($host, $user, $pass, $db) or die("connection error");