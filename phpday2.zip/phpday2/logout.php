<?php session_start(); ?>

<?php
if (isset($_SESSION['success']) || $_SESSION['success'] == 'yes') {
    unset($_SESSION['success']);
    session_destroy(); //destroys all session variables in the current session
    header("LOCATION:login.php");
} else {
    header("LOCATION:accessdenied.php");
}
?>