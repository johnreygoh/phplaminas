<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View records</title>
</head>

<body>

    <a href="addrecord.php">add record</a><br />


    Employee Records
    <hr />

    <?php
    require("dbconnection/connect.php");
    $query = "select * from Employees";
    // $result = mysqli_query($con, $query) or die(mysqli_error($con));
    $result = mysqli_query($con, $query) or die("error in query");

    if (mysqli_num_rows($result) > 0) {
        echo "
        <table border=1>
        <tr>
        <th>ID</th>
        <th>NAME</th>
        <th>DEPARTMENT</th>
        <th>SALARY</th>
        <th>action</th>
        </tr>
        ";

        while ($row = mysqli_fetch_row($result)) {
            echo "
            <tr>
            <td>$row[0]</td>
            <td>$row[1]</td>
            <td>$row[2]</td>
            <td>$row[3]</td>
            <td>
            <a 
                href=\"deleterecord.php?id=$row[0]\" 
                onClick=\"return confirm('sure to delete?');\">
            delete
            </a>
            </tr>    
            ";
        }

        echo "</table>";
    } else {
        //if no records
        echo "no records found.";
    }

    //close connection
    mysqli_close($con);
    ?>

</body>

</html>