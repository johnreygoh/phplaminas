<?php session_start(); ?>

<?php
if (!isset($_SESSION['success']) || $_SESSION['success'] != 'yes') {
    header("LOCATION: accessdenied.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>secured page 2</title>
</head>

<body>
    welcome to secured 2 page
    <br />
    secured pages:<br />
    <a href="secured1.php">secured page 1</a><br />
    <a href="secured2.php">secured page 2</a><br />
    <a href="logout.php">logout</a>

</body>

</html>