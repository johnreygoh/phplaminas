<?php

//process deletion and redirect to viewrecords
require("dbconnection/connect.php");

$id = $_GET['id'];
$query = "delete from employees where id = $id";
mysqli_query($con, $query) or die(mysqli_error($con));
mysqli_close($con);
header("LOCATION:viewrecords.php");