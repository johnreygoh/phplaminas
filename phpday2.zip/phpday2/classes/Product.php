<?php
//checking data type
declare(strict_types=1);

class Product
{
    // properties
    public string $name;
    public int $price;
    public int $discount;

    // constructor
    public function __construct($name, $price, $discount)
    {
        $this->name = $name;
        $this->price = $price;
        $this->discount = $discount;
    }

    public function getproduct(): string
    {
        return "{$this->name},{$this->price},{$this->discount}";
    }
}