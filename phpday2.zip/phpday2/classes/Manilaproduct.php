<?php
//demo of class inheritance

class Manilaproduct extends Product
{

    public function getproduct(): string
    {
        return "Manila-{$this->name},{$this->price},{$this->discount}";
    }
}