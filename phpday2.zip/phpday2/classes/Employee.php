    <?php
    //sample class call without constructor
    class Employee
    {

        public string $name;
        public string $address;

        public function getemployee(): string
        {
            return $this->name . " lives at " . $this->address;
        }
    }