<?php

declare(strict_types=1);

namespace Application2\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Laminas\View\View;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        return new ViewModel();
    }

    public function page1Action()
    {
        return new ViewModel();
    }
}