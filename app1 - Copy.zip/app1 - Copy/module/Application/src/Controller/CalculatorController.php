<?php

declare(strict_types=1);

namespace Application\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Laminas\View\View;

class CalculatorController extends AbstractActionController
{
    public function indexAction()
    {
        return new ViewModel();
    }

    public function addAction()
    {
        // getting values from url
        $data = null;
        $request = $this->getRequest();

        if ($request->isGet()) {
            $data['n1'] = $this->params()->fromQuery('num1', 0);
            $data['n2'] = $this->params()->fromQuery('num2', 0);
            $data['answer'] = $data['n1'] + $data['n2'];
        }

        return new ViewModel(['data' => $data]);
    }
}