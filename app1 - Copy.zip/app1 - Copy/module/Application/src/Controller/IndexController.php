<?php

declare(strict_types=1);

namespace Application\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Laminas\View\View;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        return new ViewModel();
    }

    public function submitemployeeAction()
    {
        return new ViewModel();
    }


    public function page1Action()
    {
        //demo pass data from controller to view
        // $name = "Jose";
        // $age = 34;
        // $address = "Manila";
        // return new ViewModel(['n' => $name, 'a' => $age, 'ad' => $address]);

        // $data['name'] = "lana";
        // $data['age'] = 36;
        // $data['address'] = "Pasig";
        // return new ViewModel(['data' => $data]);

        $data = null;                       // get values from form post
        $request = $this->getRequest();     // we check and get values from the request    
        if ($request->isPost()) {
            $data['name'] = $this->params()->fromPost("name", "none");
            $data['age'] = $this->params()->fromPost("age", "none");
            $data['address'] = $this->params()->fromPost("address", "none");
        }
        return new ViewModel(['data' => $data]);
    }

    public function page2Action()
    {
        return new ViewModel();
    }

    public function page3Action()
    {
        return new ViewModel();
    }

    public function page4Action()
    {
        return new ViewModel();
    }
}