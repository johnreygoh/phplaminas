<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practice6</title>
</head>

<body>

    php arrays and loops <br />

    <?php

    // include("myfunctions/functionset1.php"); // load the page even if not exist
    // include
    // require
    // require_once
    require("myfunctions/functionset1.php"); // does not load the page if required file is missing

    $cars = array("Volvo", "BYD", "Toyota");

    echo "array count:" . count($cars) . "<br />";
    echo "get item from array:" . $cars[1] . "<br />";

    try {
        //risky code
        echo "get item:" . getcar(2, $cars) . "<br />";
    } catch (Exception $e) {
        echo "<br />Error:" . $e->getMessage();
    } finally {
        echo "<br />this will run whether or not have errors.<br />";
    }

    // loop over the array items
    foreach ($cars as $car) {
        echo "$car<br />";
    }
    ?>

    <br />

    <?php echo greetme(); ?>

    <br />

    <?php

    try {
        echo getnetsalary(8000, 4, 4000);
    } catch (Exception $e) {
        echo $e->getMessage();
    }

    ?>







</body>

</html>