<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practice3process</title>
</head>

<body>

    values submitted: <br />
    <?php
    $user = $_POST["txtUsername"];
    $pass = $_POST["passPassword"];

    echo "user submitter user:$user, password:$pass";
    ?>
</body>

</html>