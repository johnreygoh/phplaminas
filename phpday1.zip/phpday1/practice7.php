<?php

// string functions
$word = "  good morning  ";
$dirty = "<script>alert('hahahaha');</script>";
echo "length: " . strlen($word) . "<br />";
echo "length without whitespaces(left/right): " . strlen(trim($word)) . "<br />";
echo "upper: " . strtoupper($word) . "<br />";
echo "lower: " . strtolower($word) . "<br />";
echo "no of words: " . str_word_count($word) . "<br />";
echo "first 4 chars: " . substr(trim($word), 0, 4) . "<br />";
echo "last 3 chars: " . substr(trim($word), strlen(trim($word)) - 3, 3) . "<br />";
echo htmlspecialchars($dirty) . "<br />";
echo "replace all o with e:" . str_replace('o', 'e', $word) . "<br />";