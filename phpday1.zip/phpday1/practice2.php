<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practice 2</title>
</head>

<body>

    <?php

    //variables
    $firstname = "jose";
    $byear = 1972;
    $yearnow = date("Y");
    $age = $yearnow - $byear; //PEMDAS

    //php dates
    //php codes always use php server time
    //php.ini for timezone
    echo date("F d, Y (D)") . "<br />"; //September 2, 2025 (Tue) 
    echo date("M d, Y h:i a") . "<br />"; //Sep 2, 2025 2:21 pm

    echo "Welcome $firstname, $age year(s) old. <br />";
    ?>

</body>

</html>