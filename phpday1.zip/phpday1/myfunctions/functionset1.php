<?php

function greetme()
{
    return "hi there";
}

function getnetsalary($rateperday, $days, $totaldeductions)
{
    if (is_numeric($rateperday)) {
        $rpd = $rateperday;
    } else {
        throw new Exception("entered rate per day is not numeric.");
    }

    if (is_integer($days)) {
        $d = $days;
    } else {
        throw new Exception("entered number of days is not an integer.");
    }

    if (is_numeric($totaldeductions)) {
        $td = $totaldeductions;
    } else {
        throw new Exception("entered total deductions is not numeric.");
    }

    return ($rpd * $d) - $td;
}





function getcar($item, $cars)
{

    $count = count($cars) - 1;
    if ($item > $count) {
        throw new Exception("item number out of bounds");
    }

    return $cars[$item];
}