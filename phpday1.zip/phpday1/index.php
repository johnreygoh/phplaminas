<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Fundamentals</title>
</head>

<body>

    Topics: <br />
    <a href="practice1.php">practice1</a><br />
    <a href="practice2.php">practice2</a><br />
    <a href="practice3.php">practice3</a><br />
    <a href="practice4.php">practice4</a><br />
    <a href="practice5.php">practice5</a><br />
    <a href="practice6.php">practice6</a><br />
    <a href="practice7.php">practice7</a><br />
    <a href="practice1.php">practice1</a><br />
    <a href="practice1.php">practice1</a><br />
    <a href="practice1.php">practice1</a><br />







</body>

</html>