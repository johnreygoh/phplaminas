<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practice4</title>
</head>

<body>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        name <input type="text" name="text1"> <br />
        birth date <input type="date" name="date1"><br />
        <input type="submit" name="button1">
    </form>


    <?php
    //check if variable or a form has been set or submitted
    if (!isset($_POST['button1'])) {
        echo "please submit values";
    } else {
        $name = $_POST['text1'];
        $birthdate = $_POST['date1'];
        echo $name . "birthdate:" . $birthdate;
    }
    ?>



</body>

</html>