<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practice5</title>
</head>

<body>
    demo of conditional statements - IF and Switch<br />
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        name <input type="text" name="txtName"><br />
        gender
        <select name="cboGender">
            <option value="male">male</option>
            <option value="female">female</option>
            <option value="others">others</option>
        </select><br />

        civil status
        <input type="radio" name="radCivil" value="single" checked>single
        <input type="radio" name="radCivil" value="married">married

        <br />
        <input type="submit" name="button1">


    </form>


    <?php
    if (isset($_POST['button1'])) {
        $name = $_POST['txtName'];
        $gender = $_POST['cboGender'];
        $cs = $_POST['radCivil'];
        $title = "";

        // good day MR./MISS/MRS. <name>
        if ($gender == "male") {
            $title = "Mr.";
        } elseif ($gender == "female") {

            switch ($cs) {
                case 'single':
                    $title = "Miss ";
                    break;
                case 'married':
                    $title = "Mrs.";
                    break;
                default:
                    $title = "";
                    break;
            }
        } else {
            $title = "";
        }

        echo "Good day $title $name!";
    }

    ?>







</body>

</html>