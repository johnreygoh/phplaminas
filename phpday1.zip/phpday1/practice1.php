<!DOCTYPE html>
<html lang=<?= "en" ?>>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= "practice1"; ?></title>
</head>

<body>


    <!-- comment in html -->
    <?php
    //echo "this is in php" 
    ?>

    <br />

    <?php //<?= "another line in php"; 
    ?>

    <?php

    $name = "jose";

    echo 'sample 1:' . $name . "<br />";
    echo "sample 2: $name <br />";
    echo "sample 3:";
    ?>





</body>

</html>