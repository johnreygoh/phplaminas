<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practice 3</title>
</head>

<body>

    <form method="post" action="practice3process.php">
        username: <input type="text" name="txtUsername"> <br />
        password: <input type="password" name="passPassword"> <br />
        <input type="submit" name="submit1">
    </form>

</body>

</html>