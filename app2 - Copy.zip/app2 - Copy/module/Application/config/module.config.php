<?php

declare(strict_types=1);

namespace Application;

use Application\Controller\Factory\ProductControllerFactory;
use Application\Model\Factory\ProductRepositoryFactory;
use Application\Model\ProductRepository;
use Laminas\Router\Http\Literal;
use Laminas\Router\Http\Segment;
use Laminas\ServiceManager\Factory\InvokableFactory;
//database packages
use Laminas\Db\Adapter\AdapterInterface;
use Laminas\Db\ResultSet\ResultSet;
use Laminas\Db\TableGateway\TableGateway;
use Application\Model\Product;
use Application\Model\ProductTable;


return [
    'router' => [
        'routes' => [
            'home' => [
                'type'    => Literal::class,
                'options' => [
                    'route'    => '/',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'index',
                    ],
                ],
            ],
            'application' => [
                'type'    => Segment::class,
                'options' => [
                    'route'    => '/application[/:action]',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'index',
                    ],
                ],
            ],
            'product' => [
                'type'    => Segment::class,
                'options' => [
                    'route'    => '/product[/:action]',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'index',
                    ],
                ],
            ],
            'product-view' => [
                'type'    => 'Segment',
                'options' => [
                    'route'    => '/product/view[:id]',
                    'constraints' => ['id' => '[1-9]\d*'],
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'view',
                    ],
                ],
            ],


            'product-add' => [
                'type' => Literal::class,
                'options' => [
                    'route' => '/product/add',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action' => 'add'
                    ]
                ]
            ],
            'product-edit' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/product/edit[/:id]',
                    'constraints' => ['id' => '[1-9]\d*'],
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action' => 'edit'
                    ]
                ]
            ],
            'product-delete' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/product/delete[/:id]',
                    'constraints' => ['id' => '[1-9]\d*'],
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action' => 'delete'
                    ]
                ]
            ],


        ],
    ],

    'service_manager' => [
        'factories' => [
            ProductTable::class => function ($container) {
                $tableGateway = $container->get('ProductTableGateway');
                return new ProductTable($tableGateway);
            },
            'ProductTableGateway' => function ($container) {
                $dbAdapter = $container->get(AdapterInterface::class);
                $resultSetPrototype = new ResultSet();
                $resultSetPrototype->setArrayObjectPrototype(new Product());
                return new TableGateway('product', $dbAdapter, null, $resultSetPrototype);
            },
        ],
    ],
    'controllers' => [
        'factories' => [
            // Controller\IndexController::class => InvokableFactory::class,
            Controller\IndexController::class => ProductControllerFactory::class,

        ],
    ],
    'view_manager' => [
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => [
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'application/index/index' => __DIR__ . '/../view/application/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ],
        'template_path_stack' => [
            __DIR__ . '/../view',
        ],
    ],
];