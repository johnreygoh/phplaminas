<?php

namespace Application\Model;

use Laminas\Db\TableGateway\TableGatewayInterface;
use RuntimeException;

class ProductTable
{
    private $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll($searchQuery = null)
    {
        if (! $searchQuery) {
            return $this->tableGateway->select();
        }
        return $this->tableGateway->select(['name LIKE ?' => '%' . $searchQuery . '%']);
    }

    public function findProduct($id)
    {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(['id' => $id]);
        $row = $rowset->current();
        if (! $row) {
            throw new RuntimeException(sprintf('Could not find row with identifier %d', $id));
        }
        return $row;
    }

    public function saveProduct(Product $product)
    {
        $data = ['name' => $product->name, 'price' => $product->price];
        $id = (int) $product->id;

        if ($id === 0) {
            $this->tableGateway->insert($data);
            return;
        }

        if (! $this->findProduct($id)) {
            throw new RuntimeException(sprintf('Cannot update product with identifier %d; does not exist', $id));
        }

        $this->tableGateway->update($data, ['id' => $id]);
    }

    public function deleteProduct($id)
    {
        $this->tableGateway->delete(['id' => (int) $id]);
    }
}