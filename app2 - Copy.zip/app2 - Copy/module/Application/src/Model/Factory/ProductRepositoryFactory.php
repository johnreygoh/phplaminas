<?php

namespace Application\Model\Factory;

use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Application\Model\ProductRepository;
use Psr\Container\ContainerInterface as ContainerContainerInterface;

class ProductRepositoryFactory implements FactoryInterface
{
    public function __invoke(ContainerContainerInterface $container, $requestedName, ?array $options = null)
    {
        return new ProductRepository;
    }
}