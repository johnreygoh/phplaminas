<?php

namespace Application\Model;

class ProductRepository
{

    private $products = [
        1 => ['id' => 1, 'name' => 'Laptop Pro', 'price' => 56000],
        2 => ['id' => 2, 'name' => 'Wireless Mouse', 'price' => 800],
        3 => ['id' => 3, 'name' => 'Mechanical Keyboard', 'price' => 2000],
    ];

    // crud functions
    public function findAll()
    {
        return $this->products;
    }
    public function findById(int $id)
    {
        return $this->products[$id] ?? null;
    }
}