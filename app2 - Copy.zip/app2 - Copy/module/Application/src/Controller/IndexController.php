<?php

declare(strict_types=1);

namespace Application\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Application\Model\ProductRepository;
use Application\Form\ProductForm;
use Application\Model\ProductTable;
use Application\Model\Product;

class IndexController extends AbstractActionController
{

    // // //reference to our model repository
    // // private $productRepository;

    // // //constructor to autorun functions or assignments
    // // public function __construct(ProductRepository $productRepository)
    // // {
    // //     $this->productRepository = new ProductRepository();
    // // }

    // private $table;

    // public function __construct(ProductTable $table)
    // {
    //     $this->table = $table;
    // }


    // // private $productRepository = new ProductRepository();

    // public function indexAction()
    // {
    //     return new ViewModel();
    // }

    // //display records
    // public function viewAction()
    // {
    //     // if this function in controller will perform crud
    //     // set access of $products in model as public
    //     // $records = $this->productRepository->products;
    //     // return new ViewModel(['products' => $records]);

    //     // return new ViewModel(['products' => $this->productRepository->findAll()]);
    //     return new ViewModel(['products' => $this->table->fetchAll()]);
    // }

    // // search by id
    // public function searchAction()
    // {
    //     // $id = (int) $this->params()->fromRoute('id', 0);
    //     $id = (int) $this->params()->fromQuery('id', 0);

    //     if ($id === 0) {
    //         return $this->redirect()->toRoute('product/view');
    //     }

    //     // $product = $this->productRepository->findById($id);
    //     $product = $this->table->findProduct($id);

    //     if (!$product) {
    //         $this->getResponse()->setStatusCode(404);
    //         return;
    //     }

    //     return new ViewModel(['product' => $product]);
    // }

    // public function addAction()
    // {
    //     // create instnce of laminas-form, send form to view, process adding new item
    //     $form = new ProductForm();
    //     $form->get('submit')->setValue('Add');

    //     // checking and processing of add new item
    //     $request = $this->getRequest();
    //     if (!$request->isPost()) {
    //         return ['form' => $form];
    //     }

    //     // logic for adding item in database

    //     return ['form' => $form];
    // }
    private $table;

    public function __construct(ProductTable $table)
    {
        $this->table = $table;
    }
    public function indexAction()
    {
        return new ViewModel();
    }
    public function viewAction()
    {
        $searchQuery = $this->params()->fromQuery('query', null);
        return new ViewModel([
            'products' => $this->table->fetchAll($searchQuery),
            'searchQuery' => $searchQuery,
        ]);
    }

    public function addAction()
    {
        $form = new ProductForm();
        $form->get('submit')->setValue('Add');

        $request = $this->getRequest();
        if (! $request->isPost()) {
            return ['form' => $form];
        }

        $product = new Product();
        $form->setInputFilter($product->getInputFilter());
        $form->setData($request->getPost());

        if (! $form->isValid()) {
            return ['form' => $form];
        }

        $product->exchangeArray($form->getData());
        $this->table->saveProduct($product);
        return $this->redirect()->toRoute('product', ['action' => 'view']);
    }

    public function editAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if ($id === 0) {
            return $this->redirect()->toRoute('product', ['action' => 'add']);
        }

        try {
            $product = $this->table->findProduct($id);
        } catch (\Exception $e) {
            return $this->redirect()->toRoute('product', ['action' => 'view']);
        }

        $form = new ProductForm();
        $form->bind($product);
        $form->get('submit')->setAttribute('value', 'Save Changes');

        $request = $this->getRequest();
        $viewData = ['id' => $id, 'form' => $form];

        if (! $request->isPost()) {
            return $viewData;
        }

        $form->setInputFilter($product->getInputFilter());
        $form->setData($request->getPost());

        if (! $form->isValid()) {
            return $viewData;
        }

        $this->table->saveProduct($product);
        return $this->redirect()->toRoute('product', ['action' => 'view']);
    }

    public function deleteAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('product');
        }

        $request = $this->getRequest();
        if ($request->isPost()) {
            $del = $request->getPost('del', 'No');

            if ($del == 'Yes') {
                $id = (int) $request->getPost('id');
                $this->table->deleteProduct($id);
            }
            return $this->redirect()->toRoute('product', ['action' => 'view']);
        }

        return ['id' => $id, 'product' => $this->table->findProduct($id)];
    }
}