<?php

namespace Application\Controller\Factory;

use Interop\Container\ContainerInterface;
use Laminas\ServiceManager\Factory\FactoryInterface;
use Application\Controller\IndexController;
use Application\Model\ProductRepository;
use Psr\Container\ContainerInterface as ContainerContainerInterface;
use Application\Model\ProductTable;

class ProductControllerFactory implements FactoryInterface
{

    public function __invoke(ContainerContainerInterface $container, $requestedName, ?array $options = null)
    {
        // $productRepository = $container->get(ProductRepository::class);
        // return new IndexController($productRepository);

        $productTable = $container->get(ProductTable::class);
        return new IndexController($productTable);
    }
}