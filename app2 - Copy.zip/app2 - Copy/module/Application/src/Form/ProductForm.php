<?php

namespace Application\Form;

use Laminas\Form\Form;

class ProductForm extends Form
{
    public function __construct($name = null)
    {
        parent::__construct('product');
        $this->setAttribute('method', 'post');

        $this->add(['name' => 'id', 'type' => 'hidden']);
        $this->add(['name' => 'name', 'type' => 'text', 'options' => ['label' => 'Product Name']]);
        $this->add(['name' => 'price', 'type' => 'text', 'options' => ['label' => 'Price']]);
        $this->add(['name' => 'submit', 'type' => 'submit', 'attributes' => ['value' => 'Go', 'id' => 'submitbutton']]);
    }
}