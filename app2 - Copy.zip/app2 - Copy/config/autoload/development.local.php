<?php

/**
 * Local Configuration Override for DEVELOPMENT MODE.
 *
 * This configuration override file is for providing configuration to use while
 * in development mode. Run:
 *
 * <code>
 * $ composer development-enable
 * </code>
 *
 * from the project root to copy this file to development.local.php and enable
 * the settings it contains.
 *
 * You may also create files matching the glob pattern `{,*.}{global,local}-development.php`.
 */

return [
    'view_manager' => [
        'display_exceptions' => true,
    ],

    // connect to mysql
    // 'db' => [
    //     'driver' => 'Pdo_Mysql',
    //     'database' => 'laminasdb',
    //     'username' => 'adminjohn',
    //     'password' => '123',
    //     'hostname' => '127.0.0.1',
    // ],

    // connect to sqlite
    'db' => [
        'driver' => 'Pdo_Sqlite',
        'database' => 'data/products.db',
    ],


];